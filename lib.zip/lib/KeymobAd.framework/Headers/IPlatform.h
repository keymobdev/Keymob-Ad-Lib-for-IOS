//
//  IBannerPlatform.h
//  platformmanager
//
//  Created by keymob.com on 15-3-15.
//  Copyright (c) 2015 keymob. All rights reserved.
//

#ifndef popstar3_IBannerPlatform_h
#define popstar3_IBannerPlatform_h

#define AD_TYPES_BANNER 0
#define AD_TYPES_INTERSTITIAL 1
#define AD_TYPES_APPWALL 2
#define AD_TYPES_VIDEO 3

#define BANNER_POSITIONS_Absolute    0
#define BANNER_POSITIONS_TOP_LEFT 1
#define BANNER_POSITIONS_TOP_CENTER 2
#define BANNER_POSITIONS_TOP_RIGHT 3
#define BANNER_POSITIONS_MIDDLE_LEFT 4
#define BANNER_POSITIONS_MIDDLE_CENTER 5
#define BANNER_POSITIONS_MIDDLE_RIGHT 6
#define BANNER_POSITIONS_BOTTOM_LEFT 7
#define BANNER_POSITIONS_BOTTOM_CENTER 8
#define BANNER_POSITIONS_BOTTOM_RIGHT 9


/**  320*50 **/
#define BANNER_SIZE_BANNER 0
/**  468*60 **/
#define BANNER_SIZE_FULL_BANNER  1
/**  320*100 **/
#define BANNER_SIZE_LARGE_BANNER 2
/**  728*90 **/
#define BANNER_SIZE_LEADERBOARD 3
/**  300*250 **/
#define BANNER_SIZE_MEDIUM_RECTANGLE 4
/**  160*600 **/
#define BANNER_SIZE_WIDE_SKYSCRAPER 5
/**  -1*-2 **/
#define BANNER_SIZE_SMART_BANNER  6

#define RATE_MODEL_RATE 0
#define RATE_MODEL_ORDER 1



#import <UIKit/UIKit.h>

static  NSString* EVENT_ON_LOADED_SUCCESS=@"onLoadedSuccess";
static NSString* EVENT_ON_LOADED_FAIL=@"onLoadedFail";
static NSString* EVENT_ON_AD_OPENED=@"onAdOpened";
static NSString* EVENT_ON_AD_CLOSED=@"onAdClosed"; ;
static NSString* EVENT_ON_AD_CLICKED=@"onAdClicked" ;
static NSString* EVENT_ON_OTHER_EVENT=@"onOtherEvent" ;

@protocol IPlatform


-(void) initPlatform:(UIViewController*) controller withKey1:(NSString*) key1 withKey2:(NSString*) key2 andParam:(NSDictionary*) param;
-(NSString*) platformName;
@end

@protocol IAppWallPlatform
-(void) loadAppWall;
-(BOOL) isAppWallReady;
-(void) showAppWall;
@end


@protocol IInterstitialPlatform
-(void) loadInterstitial;
-(BOOL) isInterstitialReady;
-(void) showInterstitial;
@end


@protocol IVideoPlatform
-(void) loadVideo;
-(BOOL) isVideoReady;
-(void) showVideo;
@end

@protocol IBannerPlatform
-(void) showBannerABS:(int)sizeType atX:(int)_x atY:(int)_y;
-(void) showRelationBanner:(int)sizeType atPosition:(int)_p withOffY:(int)_y;
-(void) removeBanner;
@end

#endif
