//
//  KeymobAd.h
//  KeymobAd
//
//  Created by keymob on 15-3-26.
//  Copyright (c) 2015 keymob. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <KeymobAd/AdManager.h>
#import <KeymobAd/PlatformConfigItem.h>
#import <KeymobAd/IAdEventListener.h>
#import <KeymobAd/PlatformAdapter.h>
//! Project version number for KeymobAd.
FOUNDATION_EXPORT double KeymobAdVersionNumber;

//! Project version string for KeymobAd.
FOUNDATION_EXPORT const unsigned char KeymobAdVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KeymobAd/PublicHeader.h>


