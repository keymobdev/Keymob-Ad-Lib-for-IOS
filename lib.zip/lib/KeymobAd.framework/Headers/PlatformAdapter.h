//
//  PlatformAdapter.h
//  platformmanager
//
//  Created by keymob.com on 15-3-15.
//  Copyright (c) 2015 keymob. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "IAdEventListener.h"
@interface PlatformAdapter : NSObject <IPlatform>{
    UIViewController* controller;
    NSString* key1;
    NSString* key2;
    NSDictionary* dic;
}
@property (nonatomic, retain) id<IAdEventListener> listener;
@property (nonatomic,assign) BOOL isTesting;
-(NSString*) sourceString:(NSString*)src;
@end
